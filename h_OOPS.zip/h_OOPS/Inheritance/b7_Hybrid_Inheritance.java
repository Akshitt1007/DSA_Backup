package h_OOPS.Inheritance;

/*
        Hybrid Inheritance:
            -> Combination of Multiple inheritance and single inheritance
            -> again it's done via INTERFACES
 */
public class b7_Hybrid_Inheritance {
    public static void main(String[] args) {

    }
}
