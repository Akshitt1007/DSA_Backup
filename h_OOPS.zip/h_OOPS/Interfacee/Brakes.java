package h_OOPS.Interfacee;

public interface Brakes {

    void brake();

    void version();
}
