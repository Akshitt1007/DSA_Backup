package h_OOPS.Interfacee.Extended_interface;

public interface B{

    void greet();

}