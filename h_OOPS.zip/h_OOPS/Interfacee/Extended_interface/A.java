package h_OOPS.Interfacee.Extended_interface;

public interface A {

    void fun();
}
