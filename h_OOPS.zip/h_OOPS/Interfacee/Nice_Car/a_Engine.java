package h_OOPS.Interfacee.Nice_Car;

public interface a_Engine {

    static final int price = 1000;

    void start();
    void stop();
    void acc();
}
