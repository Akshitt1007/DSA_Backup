package h_OOPS.Interfacee.Nice_Car;

public interface b_Media {
    abstract void start();
    abstract void stop();
}
