package h_OOPS.Interfacee;

public interface Media_player {

    abstract void start();
    abstract void stop();

}
