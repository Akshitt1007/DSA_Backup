package h_OOPS.Comparing_Objects;


interface Generic_Interface<T>{
    void display( T name );
}

public class a2_Generics_Interfaces implements Generic_Interface<Integer> {

    @Override
    public void display(Integer name) {

    }
}
